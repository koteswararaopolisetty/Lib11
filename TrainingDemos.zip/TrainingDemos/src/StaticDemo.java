
public class StaticDemo 
{
	int ns;
	static int s;//To create static variable - use keyword "static"
	public StaticDemo() 
	{
		ns++;
		s++;
	}
}
