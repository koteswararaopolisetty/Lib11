package unittesting;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

public class TestGreet {
	private Greet g1;
	//Greet g1;
	@Before
	public void before()
	{
		 g1 = new Greet();
	}
	
	@After
	public void after()
	{
		 g1 = null;
	}

	@Test
	public void testGreetingReturnsMessage() {
		//System.out.println("test greeting");
//		fail("Not yet implemented");
		//Greet g1 = new Greet();	
		assertNotNull(g1);
		assertEquals("Value not equal","Good morning koti",g1.greeting("koti"));
	}
	@Test
	public void testGreetingDoesNotReturnsProperMessage() {
		//System.out.println("test greeting");
		//Greet g1 = new Greet();	
		assertNotNull(g1);
		assertNotEquals("Value not equal","Good morning Capgemini",g1.greeting("koti"));
	}
	@Ignore//It will stop the test class to run
	@Test(timeout=1000)//This test case fails because in greet.java we gave timeout as 2sec but here only 1sec @Thread.sleep(2000)
	//If we give 2000 it will work
	public void testTimeTakenByValidate() throws Exception
	{
		g1.validate("");
	}
	@Test(expected = Exception.class)
	public void TestValidateThrowsException() throws Exception
	{
//		g1.validate("user");//true
		g1.validate("admin");//false or failure because it should throw Exception
	}
}
