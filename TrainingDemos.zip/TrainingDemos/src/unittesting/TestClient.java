package unittesting;

import static org.junit.Assert.*;
import junit.framework.Assert;

import org.junit.Test;

import com.MediaItem.Book;

import exceptions.ItemException;

public class TestClient {

	@Test(expected=ItemException.class)
	public void testGetItem() {

			
				TestClient l = new TestClient();
				Assert.assertEquals(2, l.);
				//Assert.assertTrue(l.searchItemById(2));
				l.addItem(new Book(3,"t1","a1"));
				Assert.assertEquals(3, l.getItems().size());
				//Assert.assertTrue(l.searchItemById(3));
				l.addItem(new Book(4,"t2","a2"));
				Assert.assertEquals(4, l.getItems().size());
				Assert.assertFalse(l.searchItemById(2));
				
				
			}

	}

}
