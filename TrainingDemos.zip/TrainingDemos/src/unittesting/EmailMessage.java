package unittesting;

public class EmailMessage implements Message{

	@Override
	public boolean sendMessage() {
		// TODO Auto-generated method stub
		System.out.println("sending message");
		return false;
	}

}
