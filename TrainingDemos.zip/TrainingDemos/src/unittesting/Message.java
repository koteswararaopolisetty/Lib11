package unittesting;

public interface Message {
	public boolean sendMessage();
}
