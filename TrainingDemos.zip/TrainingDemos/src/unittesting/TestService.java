package unittesting;

import static org.junit.Assert.*;

import org.easymock.EasyMock;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TestService {
//	public static void main(String[] args) {
//		Service s1 = new Service();
//		EmailMessage email = new EmailMessage();
//		s1.setMessage(email);
//		System.out.println(s1.sendingmessages());
//	}
	
	Service service;
	Message message;
	
	@Before
	public void setUp()
	{
		service = new Service();
		message = EasyMock.createMock(Message.class);
		service.setMessage(message);
	}
	@After
	public void tear()
	{
		service = null;
		message = null;
	}
	@Test
	public void testSendingMessagesReturnsSent()
	{
		// For true
//		EasyMock.expect(message.sendMessage()).andReturn(true);
//		EasyMock.replay(message);
//		assertEquals("Sent", service.sendingmessages());
//		EasyMock.verify(message);
		// For false
		EasyMock.expect(message.sendMessage()).andReturn(false);
		EasyMock.replay(message);
		assertEquals("Failed", service.sendingmessages());
		EasyMock.verify(message);

	}
}
