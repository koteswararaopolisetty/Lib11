package unittesting;

public class Service {//class defines sending messages 
	
	Message message;

	public Message getMessage() {
		return message;
	}

	public void setMessage(Message message) {
		this.message = message;
	}
	public String sendingmessages()
	{
		if(this.message.sendMessage())
			return "Sent";
		return "Failed";
	}
}
