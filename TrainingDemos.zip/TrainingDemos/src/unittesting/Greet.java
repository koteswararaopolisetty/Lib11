package unittesting;

import java.util.Scanner;

public class Greet {
	public String greeting(String name){
	return "Good morning "+name;
}
	public boolean validate(String role) throws Exception
	{
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		if(role.equals("admin"))
		return true;
		throw new Exception("Illegal access");
	}
	
}