package service;

import java.util.ArrayList;

import com.MediaItem.Audio;
import com.MediaItem.Book;
import com.MediaItem.MediaItem;

import exceptions.ItemException;

public class CgLibrary implements Library{
	ArrayList<MediaItem> items;
	public CgLibrary() {
		items = new ArrayList<MediaItem>();
		items.add(new Book(1, "Tom", "Tom"));
		items.add(new Audio(2, "jerry", "jerry"));
	}

	@Override
	public void addItem(MediaItem item) {
		// TODO Auto-generated method stub
		System.out.println("items adding.......");
		items.add(item);
		
	}

	@Override
	public boolean searchItem(int id) throws ItemException {
		System.out.println("searching...........");
		for(MediaItem item : items)
		{
			if(item.getId()==id)
				return true;
		}
		throw new ItemException();
		
	}

	@Override
	public boolean deleteItem(int id) throws ItemException {
		System.out.println("deleting..........");
		for (int i = 0; i < items.size(); i++) {
			if(id==items.get(i).getId())
			{
				items.remove(i);
				return true;
			}
		}
		throw new ItemException();
	}

	@Override
	public ArrayList<MediaItem> getItems() {
		// TODO Auto-generated method stub
		return items;
	}

	@Override
	public MediaItem updateItem(MediaItem item) throws ItemException {
		System.out.println("updating.........");
		for (int i = 0; i < items.size(); i++) {
			if(item.getId() == items.get(i).getId())
			{
				items.set(i, item);
				return item;
			}
		}
		throw new ItemException();
	}

}
