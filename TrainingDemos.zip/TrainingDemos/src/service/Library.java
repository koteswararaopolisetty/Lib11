package service;

import java.util.ArrayList;

import com.MediaItem.MediaItem;

import exceptions.ItemException;

public interface Library {
	void addItem(MediaItem item);
	boolean searchItem(int id) throws ItemException;
	boolean deleteItem(int id) throws ItemException;
	ArrayList<MediaItem>getItems();
	MediaItem updateItem(MediaItem item)throws ItemException;
}

