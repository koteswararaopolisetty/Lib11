import java.util.ArrayList;
import java.util.Iterator;


public class ListDemo {
	public static void main(String[] args) {
		ArrayList<Integer> list = new ArrayList<Integer>();//it will print duplicate values also
		//byte, Character, Short, Integer, Long, float, Double, Boolean - Wrapper Classes
		list.add(2);
		list.add(5);
		list.add(32);
		list.add(52);
		list.add(25);
		list.add(53);
		System.out.println(list.size());
		//next
		for(int i=0;i<list.size();i++)
		{
			if(list.get(i)==2)
				list.remove(i);
			System.out.println("*******"+list.get(i)+"*******");
		}
		System.out.println("*******Iterator********");
		Iterator<Integer> it = list.iterator();
		while(it.hasNext())
			System.out.println(it.next());
		System.out.println("******For Each Loop********");
		for(Integer v:list)
		//not allowed to modify the collections in for each loop
			//if(v==20)
				//list.remove(v);
			System.out.println(v);
		
	}
}
