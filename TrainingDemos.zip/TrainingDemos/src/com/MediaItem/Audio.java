package com.MediaItem;


public class Audio extends MediaItem{
	String artist;

	public Audio(int id,String title,String artist) {
		super(id,title);
		this.artist = artist;
	}

	public String getArtist() {
		return artist;
	}

	public void setArtist(String artist) {
		this.artist = artist;
	}

	@Override
	public String toString() {
		return "Audio "+super.toString()+", artist=" + artist + "]";
	}

//	@Override
//	public void caldays() {
//		System.out.println("Audio cal days");
//		
//	}
	
}

