package com.MediaItem;

public class TestMedia {
	public static void main(String[] args) {
	Book b1 = new Book(123,"book","abcd");
	System.out.println(b1);
	Audio a1 = new Audio(123, "book", "koti");
	System.out.println(a1);
	//First execute till here and next
//	MediaItem m1;
//	m1 = a1;
//	m1.caldays();
//	m1 = b1;
//	m1.caldays();
}
}
