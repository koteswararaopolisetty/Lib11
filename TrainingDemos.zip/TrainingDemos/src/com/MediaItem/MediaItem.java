package com.MediaItem;


public  class MediaItem {
	int id;
	String title;
	
	public MediaItem(int id2, String title) {
		this.id = id2;
		this.title = title;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}

	//public abstract void caldays();
	
	@Override
	public String toString() {
		return "[id=" + id + ", title=" + title + "";
	}
	
	
}
