package com.jar;

public class MyJar {
	
	public int add(int a,int b)
	{
		return a+b;
	}

}
