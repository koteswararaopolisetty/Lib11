import java.util.HashSet;
import java.util.TreeSet;


public class SetDemo {
	public static void main(String[] args) {
		HashSet<Integer> set = new HashSet<Integer>(); //not sorted but not print duplicate values
		set.add(2);
		set.add(5);
		set.add(52);
		set.add(58);
		set.add(29);
		set.add(56);
		set.add(2);
		set.add(5);
		System.out.println(set);
		TreeSet<Integer> set1 = new TreeSet<Integer>();//sorted in ascending order
		set1.add(2);
		set1.add(5);
		set1.add(52);
		set1.add(58);
		set1.add(29);
		set1.add(56);
		set1.add(2);
		set1.add(5);
		System.out.println(set1);
	}
}
