package regex;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import exceptions.ItemException;

public class RegExDemo {

	public static void main(String[] args) throws ItemException{
		/*
		 * * - 0 or more
		 * ? - 0 or 1
		 * + - 1 or more
		 */
//String input = "Capgemini";
//		Pattern pattern = Pattern.compile("capgemini",Pattern.CASE_INSENSITIVE);//compile is the static method
//		Matcher m = pattern.matcher(input);
//		System.out.println(m.matches());
		String input = "";
		//String input = "s1";
		//Pattern pattern = Pattern.compile("[a-z][A-Z]");//[abc] means a or b or c 
		//Pattern pattern = Pattern.compile("[0-9].[A-Z]");//"." implies anything
		Pattern pattern = Pattern.compile("[0-9]{1,}");//Anything except space can give true
		Matcher m = pattern.matcher(input);
	System.out.println(m.matches());
//		String input = "Shop for mop hop thop";
//		Pattern pattern = Pattern.compile("hop");
//		Matcher m = pattern.matcher(input);
//		System.out.println(m.matches());
//		while(m.find())
//		{
//			System.out.println(m.group()+" ["+m.start()+"-"+m.end()+"]");
//		}
//		
//	
	
		
}

}
