
public class TestBook {

	public static void main(String[] args) {
		Book b1 = new Book(1, "abcd","abcd");
		System.out.println(b1);
	}
}
