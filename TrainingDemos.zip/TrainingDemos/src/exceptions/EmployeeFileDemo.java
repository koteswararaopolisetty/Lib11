package exceptions;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Scanner;

public class EmployeeFileDemo {
	public static void main(String[] args) throws IOException, ClassNotFoundException {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter id and name");//input given by programmer in console
		int id = sc.nextInt();
		String name = sc.next();
		Employee e1 = new Employee(id, name);
		System.out.println(e1);
		
		FileOutputStream fileOutputStream=null;
		ObjectOutputStream objectOutputStream= null;
		fileOutputStream = new FileOutputStream("emp.dat");
		objectOutputStream = new ObjectOutputStream(fileOutputStream); 
		objectOutputStream.writeObject(e1);
		fileOutputStream.close();
		
		FileInputStream input = null;
		ObjectInputStream inputobj = null;
		input = new FileInputStream("emp.dat");
		inputobj = new ObjectInputStream(input);
		Employee e2 = (Employee) inputobj.readObject();
		System.out.println(e2);
		input.close();
		
	}
}
