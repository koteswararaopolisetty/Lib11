package exceptions;

public class ItemException extends Exception{
	String message;

	public ItemException() {
		 this.message="Item not found";
	}

	public ItemException(String message) {
		this.message = message;
		
	}

	@Override
	public String toString() {
		return "ItemException [message=" + message + "]";
	}


}
