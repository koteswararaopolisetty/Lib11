package exceptions;

public class TestMyCheckedException {

	public static void m1(int no) throws MyCheckedException {
		if(no<=0)
			throw new MyCheckedException("no cannot be less than 0");
		else
			System.out.println(Math.sqrt(no));
	}
	public static void main(String[] args){
		try {
			m1(4);
		} catch (MyCheckedException e) {
			e.printStackTrace();
		}
		try {
			m1(0);
		} catch (MyCheckedException e) { 
			e.printStackTrace();
		}

	}

}
