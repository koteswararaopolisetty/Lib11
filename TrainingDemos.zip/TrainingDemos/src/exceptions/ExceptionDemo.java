package exceptions;

import java.util.Scanner;

public class ExceptionDemo {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter two values");
		int a = sc.nextInt();
		int b = sc.nextInt();
		try{
			System.out.println("Dividing..........");
			System.out.println(a/b);
		}
		catch (Exception e){
			System.out.println("denominator value cannot be 0");
			System.out.println(e);
			e.printStackTrace();//to print where the exception is occuring and print the line no too
		}
		finally{//check note to understand this
			System.out.println("finally");//finally is a block of code that runs irrespective of whether it occurs or not
		}
		int arr[] = {1,2,3,4,5};
		try {
			System.out.println(arr[4]);
		}
		catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("index out of range");
		}
		System.out.println("main ends");
	}

}
