package exceptions;

import java.io.BufferedReader;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.Scanner;

public class FileDemo {
	public static void main(String[] args) throws IOException {
		File file1 = new File("file1.txt");
//		System.out.println(file1.getAbsolutePath());
//		System.out.println(file1.exists());
//		System.out.println(file1.createNewFile());
//		System.out.println(file1.exists());
		FileWriter writer = new FileWriter(file1);
		writer.write("Hello there\n");
		writer.write("Lunch time");
		writer.close();
		FileReader reader = new FileReader(file1);
		BufferedReader bufferedreader = new BufferedReader(reader);
		String line = null;
		while((line = bufferedreader.readLine())!=null);
			System.out.println(line);
		reader.close();
	}

}
