package exceptions;

public class MyCheckedException extends Exception{
	String message;

	public  MyCheckedException() {
		 this.message="Exception occurred";
	}

	public MyCheckedException(String message) {
		this.message = message;
	}

	@Override
	public String toString() {
		return "MyCheckedException [message=" + message + "]";
	}
	
}
