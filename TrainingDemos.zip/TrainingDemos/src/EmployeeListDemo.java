import java.util.ArrayList;

import java.util.Collections;
import java.util.List;
import java.util.Scanner;


public class EmployeeListDemo {
	public static void main(String[] args) {
		List<Employee> employees = new ArrayList<Employee>();
		Employee e1 = new Employee(1, "name1");
		employees.add(e1);
		//employees.add(new Employee(2,"name")); we can use this also
		Employee e2 = new Employee(2, "name2");
		employees.add(e2);
		Employee e3 = new Employee(3, "name3");
		employees.add(e3);
		Employee e4 = new Employee(4, "name4");
		employees.add(e4);
		Employee e5 = new Employee(5, "name5");
		employees.add(e5);
		//Collections.sort(employees);//to implement this use comparable in Emmployee.java
		for(Employee e:employees)
		System.out.println(e);
		//Display details according to EmpId entered
//		System.out.println("Enter Id of employee to be searched");
//		int id = new Scanner(System.in).nextInt();
//		boolean found = false;
//		for(Employee e:employees)
//		{
//			if(e.getId() == id){	//compare the id given to id already existed then print
//				System.out.println("Employee Found "+e);
//				found = true;
//				break;
//		}
//		}
//		if(!found)
//			System.out.println("No employee record exists for id="+id);
		List<String> cities = new ArrayList<String>();
		
				cities.add("Mumbai");
				cities.add("Pune");
				cities.add("Hyderabad");
				cities.add("Delhi");
				cities.add("Ap");
				System.out.println(cities);
				Collections.sort(cities);
				System.out.println(cities);
		
	}
}
