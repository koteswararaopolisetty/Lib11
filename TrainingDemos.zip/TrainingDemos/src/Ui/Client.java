package Ui;

import exceptions.ItemException;

import java.util.ArrayList;
import java.util.Scanner;

import com.MediaItem.Audio;
import com.MediaItem.Book;
import com.MediaItem.MediaItem;

import service.CgLibrary;
import validator.DataValidator;


public class Client {


	public static void main(String[] args) throws ItemException{
		CgLibrary library = new CgLibrary(); 
		Scanner sc=new Scanner(System.in);
		char ans =' ';	
		do{
		System.out.println("Select options:\n1.Insert details\n2.Search item by id\n3.Display Items\n4.Update Item\n5.Delete Item\n");
		int option = sc.nextInt();
		switch(option){
		case 1://Enter details
			System.out.println("Select item to be inserted:\n1. Book \n2. Audio");
			int itemtype = sc.nextInt();
			System.out.println("Enter id");
			int id=sc.nextInt();
			while(!(DataValidator.validateId(id)))
			{
				System.out.println("Enter valid id");
				id=sc.nextInt();
			}
			System.out.println("Enter title");
			 String title = sc.next();
				while(!DataValidator.validateTitle(title))
				{
					System.out.println("Enter valid title");
					title=sc.next();
				}
			switch(itemtype){
			case 1:
				System.out.println("Enter author");
				String author = sc.next();
				library.addItem(new Book(id, title, author));
				break;
			case 2:
				System.out.println("Enter artrist");
				String artrist = sc.next();
				library.addItem(new Audio(id, title, artrist));
				break;
				default:
				break;
			}
			break;			
		case 2://search
			System.out.println("Enter the id to be searched");
			id=sc.nextInt();
			while(!(DataValidator.validateId(id)))
			{
				System.out.println("Enter valid id");
				id=sc.nextInt();
			}
			if(library.searchItem(id))
				System.out.println("item with id "+id+"found");
			break;
		case 3://get all
			ArrayList<MediaItem> items = library.getItems();
			for(MediaItem item : items)
				System.out.println(item);
			break;
		case 4://update
			System.out.println("Select item to be Updated:\n1. Book \n2. Audio");
			 itemtype = sc.nextInt();
			System.out.println("Enter id");
			 id=sc.nextInt();
			 while(!(DataValidator.validateId(id)))
				{
					System.out.println("Enter valid id");
					id=sc.nextInt();
				}
			System.out.println("Enter title");
			 title = sc.next();
			 while(!DataValidator.validateTitle(title))
				{
					System.out.println("Enter valid title");
					title=sc.next();
				}
			switch(itemtype){
			case 1:
				System.out.println("Enter author");
				String author = sc.next();
				System.out.println("updated  "+library.updateItem(new Book(id, title, author)));
				break;
			case 2:
				System.out.println("Enter artist");
				String artrist = sc.next();
				System.out.println("updated   "+library.updateItem(new Audio(id, title, artrist)));
				break;
				default:
				break;
			}
			break;
		case 5://delete
			System.out.println("Enter item id to be deleted");
			id=sc.nextInt();
			while(!(DataValidator.validateId(id)))
			{
				System.out.println("Enter valid id");
				id=sc.nextInt();
			}
			if(library.deleteItem(id))
				System.out.println("item with id"+id+"deleted");
			break;
		case 6:
			System.out.println("Wrong choice");
			break;
			}	
		System.out.println("Do you want to continue enter Y or N");
		ans = sc.next().charAt(0);
	}
	
		
		while(ans=='Y');
		sc.close();
		
			}
}

