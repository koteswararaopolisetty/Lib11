
import java.util.HashSet;
import java.util.Set;


public class EmployeeSetDemo {

	public static void main(String[] args) {
		Set<Employee> employees = new HashSet<Employee>();
		Employee e1 = new Employee(1, "name1");
		//System.out.println(e1.hashCode());
		employees.add(e1);
		//employees.add(new Employee(2,"name")); we can use this also
		Employee e2 = new Employee(2, "name2");
		//System.out.println(e2.hashCode());
		employees.add(e2);
		//Employee e2 = new Employee(1, "name1");//For the equals purpose
		//employees.add(e2);
		Employee e3 = new Employee(3, "name3");
		//System.out.println(e3.hashCode());//write override in employee.java
		employees.add(e3);
		Employee e4 = new Employee(4, "name4");
		//System.out.println(e4.hashCode());
		employees.add(e4);
		Employee e5 = new Employee(5, "name5");
		//System.out.println(e5.hashCode());
		employees.add(e5);
		Employee e6 = new Employee(5, "name5");
		//System.out.println(e6.hashCode());
		employees.add(e6);
		//employees.add(new Employee(5, "name5"));
		System.out.println(employees.size());
		//for(Employee e:employees)
		//System.out.println(e);
		
		
		//Set will not display duplicate values
		//Set<String> cities = new HashSet<String>();
		//cities.add("Mumbai");
		//cities.add("Pune");
		//cities.add("Hyderabad");
		//cities.add("Delhi");
		//cities.add("Mumbai");
		//System.out.println(cities);
		
	}

}
