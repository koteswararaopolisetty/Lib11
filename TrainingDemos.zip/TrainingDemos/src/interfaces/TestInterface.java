package interfaces;

public class TestInterface {
	public static void main(String[] args) {
	Print p1 = new Employee();
	p1.printing();
	Print p2 = new Car();
	p2.printing();
}
}
