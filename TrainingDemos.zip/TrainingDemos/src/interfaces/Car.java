package interfaces;

public class Car implements Print {

	@Override
	public void printing() {
		System.out.println("Car printing");
		
	}

}
