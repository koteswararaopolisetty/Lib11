package util;

public enum Gender {
	Male, Female
}
