package validator;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import exceptions.ItemException;

public class DataValidator {
	public  static  boolean validateId(int id)//throws ItemException
	{
		
//			Pattern p = Pattern.compile("[0-9]{1,}");
//			String s = Integer.toString(id);
//			Matcher m = p.matcher(s);
//			if(m.matches())
//			return true;
//		else
//		{
//			throw new ItemException("Id must be Digits only");		
//			
//		}
		Pattern p = Pattern.compile("[0-9]{1,}");
		String s = Integer.toString(id);
		Matcher m = p.matcher(s);
		return m.matches();
	}
	public  static  boolean validateTitle(String title)//throws ItemException
	{
//		String assetPattern="[A-Za-z0-9]{3,}";
//		if(Pattern.matches(assetPattern, title))
//		{
//			return true;
//		}
//		else
//		{
//			throw new ItemException("Title should be alphanumeric and minimum 3 ");
//		}
		Pattern p = Pattern.compile("[A-Za-z0-9]{3,}");
		Matcher m = p.matcher(title);
		return m.matches();
	}

}
